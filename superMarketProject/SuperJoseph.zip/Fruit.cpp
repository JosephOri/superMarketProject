#include "Fruit.h"

const float Fruit::calcPrice(int factor)
{
	float x = Farming_product::calcPrice(factor);
	if (x == 0)
		return 0;
	return x + (_sugar / 2);
}
const void Fruit::print()
{
	Farming_product::print();
	cout << " (" << _sugar << ") ";
}