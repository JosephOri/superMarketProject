#include "Product.h"
#include "Vegetable.h"
#include "Farming_product.h"
#include "Fruit.h"
#include "Milk_product.h"
int main()
{
	Product** P = new Product*;
	return 0;
}