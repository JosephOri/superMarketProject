#include "Other_milk.h"
const string Other_milk:: getNameFromNamesArray(int index)
{
	if (index < 0 || index >= _numOfNonMilkItems)
	{
		cout << "invalid index enterd" << endl;
		return "NA";
	}
	return _nonMilkNames[index];
}
void Other_milk::addNonMilkProduct(string nonMilk)//insert a name to the vector
{
	_numOfNonMilkItems++;
	_nonMilkNames.push_back(nonMilk);
}
const float Other_milk::calcPrice(int factor)
{
	float x = Milk_product::calcPrice(factor);
	if (x == 0)
		return 0;
	return x + (_numOfNonMilkItems * 5);
}
const void Other_milk::print()
{
	Milk_product::print();
	int i;
	for (i = 0; i < _numOfNonMilkItems; i++)
	{
		cout << _nonMilkNames[i] << " ";
		if (i != _numOfNonMilkItems - 1)
			cout << ",";
	}
	cout << "(" << _numOfNonMilkItems << ")";
}