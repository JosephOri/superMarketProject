#pragma once
#include "Cheese.h"
#include "Other_milk.h"
#include "Vegetable.h"
#include "Fruit.h"
#include "Package.h"
class Store
{
private:
	string _name;
	int _factor;
	int _numOfProducts;
	vector<Product*> _productsArr;

public:
	Store() :_name{ "Na" }, _factor{ 0 }, _numOfProducts{ 0 }{}//empty constructor
	Store(string name, int factor, Product* firstproduct);//constructor with the first product
	
	//get methods
	const string getName() { return _name; }
	const int getFactor() { return _factor; }
	const int getNumOfProducts() { return _numOfProducts; }
	const Product* getProductByIndex(int index);//in cpp
	
	//set methods
	void setName(string name) { _name = name; }
	void setFactor(int factor);
	void addProduct(Product* p);

	const float calcPrices();

	const void printStore();
};

