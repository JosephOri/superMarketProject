#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;
class Product
{
protected:
	int _serialNumber;
	char _positionRow;
	int _positionShelf;
	int _quantity;
	int _productType;
	int _area;
public:
	Product() :_serialNumber{ 0 }, _positionRow{ '0' }, _positionShelf{ 0 }, _quantity{ 0 }, _productType{ 0 }, _area{ 0 }{}//defult consructor
	Product(int serialnumber, char positionrow, int positionshelf , int quantity , int producttype , int area );//counstructor with values
	~Product() { cout << "destructor activated" << endl; }

	//get methods
	const int getSerialNum()const { return _serialNumber; }
	const char getRow()const { return _positionRow; }
	const int getShelf()const { return _positionShelf; }
	const int getQuantity() const { return _quantity; }
	const int getType()const { return _productType; }
	const int getArea()const { return _area; }
	
	//set methods, the implements are in Product.cpp
	void setRow(char positionrow);
	void setShelf(int positionshelf);
	void setQuantity(int quantity);
	void setType(int producttype);
	void setArea(int area);
	

	virtual const float calcPrice(int factor);

	virtual const void print();// print method

	virtual void Pure() = 0;//product is an abstract class

};

