#include "Store.h"

Store::Store(string name, int factor, Product* firstproduct)
{
	_name = name;
	if (factor < 0)
	{
		cout << "invalid factor, updated to 0" << endl;
		factor = 0;
	}
	_numOfProducts = 1;
	_productsArr.push_back(firstproduct);
}
const Product* Store::getProductByIndex(int index)
{
	if (index<0 || index>_numOfProducts)
	{
		cout << "invalid index, returnd null" << endl;
		return nullptr;
	}
	return _productsArr[index];
}
void Store::setFactor(int factor)
{
	if (factor < 0)
	{
		cout << "invalid factor" << endl;
		return;
	}
	_factor = factor;
}
void Store::addProduct(Product* p)
{
	_numOfProducts++;
	_productsArr.push_back(p);//I'm pushing p
}
const float Store:: calcPrices()
{
	int i;
	float sum = 0;
	for (i = 0; i < _numOfProducts; i++)
		sum += _productsArr[i]->calcPrice(_factor);
	return sum;	
}
const void Store::printStore()
{
	cout << "store information:" << endl;
	cout << "name: " << _name << endl;
	cout << "fame factor: " << _factor << endl;
	cout << "number of products:  " << _numOfProducts << endl;
	cout << "products information: " << endl;
	int i;
	for (i = 0; i < _numOfProducts; i++)
	{
		cout << i+1 << ". product: ";
		_productsArr[i]->print();
		cout << endl;
	}

}