#pragma once
#include "Milk_product.h"
class Cheese:public Milk_product
{
protected:
	int _numCheeseExtras;

public:

	Cheese() :Milk_product(), _numCheeseExtras{ 0 }{}//empty constructor
	Cheese(int serialnumber, char positionrow, int positionshelf, int quantity, int producttype, int area,
		int milkProductType, string name, int numOfColors, float fats, int numCheeseExtras) :
		Milk_product(serialnumber, positionrow, positionshelf, quantity, producttype, area,
			milkProductType, name, numOfColors, fats)
	{
		if (numCheeseExtras < 0)
		{
			cout << "negative ammount of cheese extras, updated to 0" << endl;
			numCheeseExtras = 0;
		}
		_numCheeseExtras = numCheeseExtras;
	}//constructor vith values
	
	const int getCheeseExtras() { return _numCheeseExtras; }//get

	void setCheeseExtras(int extras);//set


	virtual const void print();

	virtual const float calcPrice(int factor);

	virtual void Pure() { cout << "pure was called" << endl; }
};

