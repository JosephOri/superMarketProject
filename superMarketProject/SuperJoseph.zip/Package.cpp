#include "Package.h"

const float Package::calcPrice(int factor)
{
	float x = Product::calcPrice(factor);
	return x * 2 * _numOfItems + (_numOfColors / 3);
}

const void Package::print()
{
	Product::print();
	int i;
	for (i = 0; i < _numOfItems; i++)
	{
		cout << _productNames[i] << " ";
		if (i != _numOfItems - 1)
			cout << ",";
	}
	cout << "(" << _numOfColors << "," << _numOfItems << ")";
}
string Package:: getNameFromNamesArray(int index)
{
	if (index < 0)
	{
		cout << "negative index enterd, returned NA" << endl;
		return "NA";
	}
	return _productNames[index];
}