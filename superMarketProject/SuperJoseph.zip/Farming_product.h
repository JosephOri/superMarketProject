#pragma once
#include "Product.h"
class Farming_product:public Product
{
protected:
	int _farmingProductType;
	string _name;
	int _goodSeasons;
	int _suplliersNum;
public:
	Farming_product() :Product(), _name{ "NA" }, _farmingProductType{ 0 }, _goodSeasons{ 0 }, _suplliersNum{ 0 }{}//defult constructor
	Farming_product(int serialnumber, char positionrow, int positionshelf, int quantity, int producttype, int area,
		int FarmingProductType,string name,int goodseasons,int suplliersNum):
		Product( serialnumber, positionrow, positionshelf, quantity, producttype, area)
		{
		if (FarmingProductType < 1 || FarmingProductType > 2)
		{
			cout << "invalid farming product type, updated to 0" << endl;
			FarmingProductType = 0;
		}
		if (goodseasons < 1 || goodseasons>4)
		{
			cout << "invalid good seasons, updated to 0" << endl;
			goodseasons = 0;
		}
		if (suplliersNum < 0)
		{
			cout << "invali supliers num, updated to 0" << endl;
			suplliersNum = 0;
		}
		_name = name;
		_suplliersNum = suplliersNum;
		_goodSeasons = goodseasons;
		_farmingProductType = FarmingProductType;
	
		}//constructor with values

	~Farming_product() {}//destructor

	//get methods
	int getFarmingProductType() { return _farmingProductType; }
	string getName() { return _name; }
	int getGoodseasons() { return _goodSeasons; }
	int getSuplliersNum() { return _suplliersNum; }

	//set methods
	void setFarmingProductType(int type) {_farmingProductType = type; }
	void setName(string name) { _name = name; }
	void setGoodSeasons(int good) { _goodSeasons = good; }
	void setSuplliersNum(int num) { _suplliersNum = num; }

	virtual const float calcPrice(int factor);

	virtual const void print();

	virtual void Pure() { cout << "pure was called" << endl; }


	
};

