#pragma once
#include "Product.h"
class Milk_product:public Product
{
protected:
	int _milkProductType;
	string _name;
	int _numOfColors;
	float _fats;


public:
	Milk_product() :Product(), _milkProductType{ 0 }, _name{ "NA" }, _numOfColors{ 0 }, _fats{ 0 }{}//empty constructor
	Milk_product(int serialnumber, char positionrow, int positionshelf, int quantity, int producttype, int area,
		int milkProductType, string name, int numOfColors, float fats) :
		Product(serialnumber, positionrow, positionshelf, quantity, producttype, area)
	{
		if (milkProductType > 4 || milkProductType < 1)
		{
			cout << "tried to set invalid type, updeted to 0 " << endl;
			milkProductType = 0;
		}
		if (fats < 0)
		{
			cout << "negative ammout of fats enterd , updeted to 0" << endl;
			fats = 0;
		}
		if (numOfColors < 0)
		{
			cout << "tried to set invalid numOfColors, updeted to 0 " << endl;
			numOfColors = 0;
		}
		_milkProductType= milkProductType ;
		_name= name ;
		_numOfColors= numOfColors;
		_fats= fats ;
	
	}//constructor with values

	//set methods
	void setMilkProductType(int type);
	void setName(string name);
	void setNumOfColors(int num);
	void setFats(float fats);
	
	//get methods
	const int getMilkProductType() { return _milkProductType; }
	const string getName() { return _name; }
	const int getNumOfColors() { return _numOfColors; }
	const float getFats() { return _fats; }

	virtual const float calcPrice(int factor);

	virtual const void print();

	virtual void Pure() { cout << "pure was called" << endl; }


};

