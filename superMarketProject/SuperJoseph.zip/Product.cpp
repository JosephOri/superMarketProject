#include "Product.h"

Product::Product(int serialnumber , char positionrow, int positionshelf , int quantity , int producttype , int area )
{
	if (positionrow < 'A' || positionrow>'Z')
	{
		cout << "invalid row updated to '0'" << endl;
		positionrow = '0';
	}
	if (positionshelf < 0 || positionshelf>5)
	{
		cout << "invalid shelf updated to 0" << endl;
		positionshelf = 0;
	}
	if (quantity < 0)
	{
		cout << "invalid quantity updated to 0" << endl;
		quantity = 0;
	}
	if (producttype < 0 || producttype > 3)
	{
		cout << "invalid type updated to 0" << endl;
		producttype = 0;
	}
	if (area < 0 || area>3)
	{
		cout << "invalid area updated to 0" << endl;
		area = 0;
	}
	_productType = producttype;
	_area = area;
	_quantity = quantity;
	_positionShelf = positionshelf;
	_positionRow = positionrow;
	_serialNumber = serialnumber;

}
const float Product::calcPrice(int factor)
{
	if (factor < 0)
	{
		cout << "negative factor" << endl;
		return 0;
	}
	return factor * _quantity * _area;
}
//set methods
void Product::setArea(int area)
{
	if (area < 0 || area>3)
	{
		cout << "invalid area updated to 0" << endl;
		area = 0;
	}
	_area = area;
}
void Product::setQuantity(int quantity)
{
	if (quantity < 0)
	{
		cout << "invalid quantity' updated to 0" << endl;
		quantity = 0;
	}
	_quantity = quantity;
}
void Product::setType(int producttype)
{
	if (producttype < 0 || producttype < 3)
	{
		cout << "invalid type updated to 0" << endl;
		producttype = 0;
	}
	_productType = producttype;
}
void Product::setRow(char positionrow)
{
	if (positionrow < 'A' || positionrow>'Z')
	{
		cout << "invalid row updated to '0'" << endl;
		positionrow = '0';
	}
	_positionRow = positionrow;
}
void Product::setShelf(int positionshelf)
{
	if (positionshelf < 0 || positionshelf>5)
	{
		cout << "invalid shelf updated to 0" << endl;
		positionshelf = 0;
	}
	_positionShelf = positionshelf;
}

const void Product::print()
{
	cout << _serialNumber << " " << _positionRow << " " << _positionShelf << " " << "(" << _quantity << "," << _productType << "," << _area << ") ";
}