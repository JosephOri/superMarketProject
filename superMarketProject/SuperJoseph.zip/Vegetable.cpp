#include "Vegetable.h"
 
const float Vegetable::calcPrice(int factor)
{
	float x = Farming_product::calcPrice(factor);
	if (x == 0)
		return 0;
	return x + (_numVitamins * 2);
}
const void Vegetable::print()
{
	Farming_product::print();
	cout << " (" << _numVitamins << ")";
}