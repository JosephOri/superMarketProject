#pragma once
#include "Product.h"
class Package: public Product
{
protected:
	int _numOfItems;
	vector<string> _productNames;
	int _numOfColors;

public:
	Package() :Product(), _numOfItems{ 0 }, _numOfColors{ 0 }{}//empty constructor
	Package(int serialnumber, char positionrow, int positionshelf, int quantity, int producttype, int area,
		string firstProduct, int numOfColors) :Product(serialnumber, positionrow, positionshelf, quantity, producttype, area)
	{//constructor with the name of the first product and the numOfcolors
		if (numOfColors < 0)
		{
			cout << "invalid num of colors, updated to 0" << endl;
			numOfColors = 0;
		}

		_numOfItems = 1;
		_numOfColors = numOfColors;
		_productNames.push_back(firstProduct);
	}
	~Package() {}
 
	//set methods
	void addName(string name) { _productNames.push_back(name); _numOfItems++; }
	void setNumOfcolors(int num) { _numOfColors = num; }

	//get methods
	int getNumOfItems() { return _numOfItems; }
	int getNumOfColors() { return _numOfColors; }
	string getNameFromNamesArray(int index);//in cpp
	

	virtual const void print();

	virtual void Pure() { cout << "pure was called" << endl; }

	virtual const float calcPrice(int factor);
};
//
