#include "Cheese.h"

void Cheese:: setCheeseExtras(int extras)
{
	if (extras < 0)
	{
		cout << "negative cheese extras numbers" << endl;
		return;
	}
	_numCheeseExtras = extras;
}
const float Cheese::calcPrice(int factor)
{
	float x = Milk_product::calcPrice(factor);
	if (x == 0)
		return 0;
	return x + _numCheeseExtras;
}
const void Cheese::print()
{
	Milk_product::print();
	cout << " (" << _numCheeseExtras << ")";	
}